export ANT_HOME=/opt/apache-ant-1.9.16
export PATH=$PATH:$ANT_HOME/bin
