import logging
from logging.handlers import RotatingFileHandler
import datetime
import os
import sys
import json
import argparse

import builder
import database
import setup_env
from utils import logger, check_output_and_logging

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--action', default='None', help='do something')
    parser.add_argument('--taskid', default='None', help='taskid')
    parser.add_argument('--depth', default=3, help='max dependency depth')

    args = parser.parse_args()
    args.depth = int(args.depth)
    return args

def dependency(args):
    if args.taskid == 'None':
        logger.error('Taskid is needed for action querydep')
        return
    path = os.path.join('/root/osschain/task', args.taskid) # Repository Address
    if not os.path.exists(path):
        logger.error('Taskid %s does not exist.' % args.taskid)
        return

    # set environment
    setup_env.change_java_default()

    logger.info(os.environ['JAVA_HOME'])

    # create a dict database
    db = database.get_database(database.DB_TYPE_DICT)

    # get builder
    bdr = builder.get_builder(path)
    if bdr == None:
        logger.error('There is no pom.xml, gradlew and build.xml in the repository!')
    # get groupid and version
    metadata = bdr.get_metadata()
    if metadata == None:
        logger.error("There is build.xml in the repository! But it hasn't been dealt with yet!")
    metadata['builder'] = bdr.type
    group_id = metadata['groupId']

    # get dependency
    bdr.parse_dependency(database=db, force_reanalyze=True)
    dependency, ndeps, stats = db.query(group_id, max_depth=args.depth)

    # count multi-level dependencies
    metadata['n_dep'] = ndeps
    metadata['d_dep'] = args.depth
    metadata['n_art'], metadata['level1'], metadata['level2'], metadata['level3'] = stats

    metadata['language'] = bdr.parse_language()

    data = {'metadata': metadata, 'dependency': dependency}

    print(json.dumps(data, indent=4), file=sys.stdout)

################################

action_dict = {
        dependency.__name__: dependency
        }

if __name__ == '__main__':
    args = parse_args()
    action = args.action
    
    if action not in action_dict:
        logger.error('Unknown action %s' % action)
        exit(1)
    logger = logging.getLogger("error")
    logger.setLevel(level = logging.DEBUG)
    today = datetime.datetime.now()
    log_path = "/root/osschain/logs/error-" + today.strftime("%Y-%m-%d-%H:%M:%S") + ".log"
    rHandler = RotatingFileHandler(log_path)
    rHandler.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s')
    rHandler.setFormatter(formatter)
    logger.addHandler(rHandler)
    try:
        action_dict[action](args)
    except:
        logger.error("Faild To Dependency Analysis",exc_info = True)
        logger.info("Finish")
        exit(0)


